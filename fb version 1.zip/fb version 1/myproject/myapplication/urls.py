from .import views
from django.urls import path

urlpatterns = [
        path('', views.index, name='home'),
        path('login/', views.login, name='login'),
        path('signup/', views.signup, name='signup'),
        path('fbconnect/', views.fbconnect, name='fbconnect'),
        path('publish/', views.publish, name='publish'),
]