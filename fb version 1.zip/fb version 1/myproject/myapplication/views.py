from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.models import User, auth
from .models import *
import requests


# Create your views here.
def index(request):
    return render(request, 'index.html')

def signup(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password1 = request.POST.get('password')
        password2 = request.POST.get('password2')
        if password1 == password2:
            if User.objects.filter(username=username).exists():
                messages.info(request, "username already taken")
                return redirect('signup')
            else:
                user=User.objects.create_user(username=username, password=password1)
                user.save()
                messages.info(request, "user created successfully")
                return redirect('login')
        else:
            messages.info(request, "password doesnt match")
            return redirect('signup')
    else:
        return render(request, 'signup.html')

def login(request):
    if request.method == 'POST':
        username= request.POST.get('username')
        password= request.POST.get('password')
        user= auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request,user)
            return redirect('fbconnect')
        else:
            messages.info(request, "invalid credentials....")
            return redirect('login')
    else:
        return render(request, 'login.html')

def fbconnect(request):
    if request.method == 'POST':
        accesstoken = request.POST.get('accesstoken')
        pageid = request.POST.get('pageid')
        appid = request.POST.get('appid')
        submit = Fbuser.objects.create(user=request.user, accesstoken=accesstoken, page=pageid, app=appid)
        submit.save()
        messages.info(request, "Submit successfully!")
        return render(request, 'publish.html')
    else:
        return render(request, 'fbconnect.html')

def publish(request):
    if request.method == 'POST':
        message = request.POST.get('message')
        tags = request.POST.get('tags')
        data = Fbuser.objects.filter(user = request.user)
        context = {'data':data}
        for i in data:
            access_token=i.accesstoken
            page_id=str(i.page)
            app_id=i.app
            print(message)
            print(page_id)
            print(access_token)
            url = 'https://graph.facebook.com/'+ page_id +'/feed'
            if request.method =='POST':
                message = request.POST.get('message')
                # tags = request.POST.get('tags')
                parameter = {'message': message, 'access_token': access_token}
                r = requests.post(url=url, params=parameter)
                postid1 = r.json()
                postid2 = postid1['id']
                print(postid2)

                myArray = postid2.split("_")
                pageid = myArray[0]
                postid = myArray[1]
                result = Post.objects.create(user=request.user , pgid=pageid , ptid=postid)
                result.save()
                if len(postid1):
                    messages.info(request, 'successfully post')
                    return render(request, 'publish.html')
                else:
                    messages.info(request, 'please try again')
                    return redirect('publish')
    else:
        return render(request, 'publish.html')








# def publish(request):
#     if request.method == 'POST':
#         access_token = request.POST.get('accesstoken')
#         URL = 'https://graph.facebook.com/100264182669977/feed'
#         PARAMS = {'message':'this  page is posting by Kajal', 'access_token':access_token}
#         r = requests.post(url=URL, params=PARAMS)
#         res = r.json()
#         print(res)
#         messages.info(request,'successfully post')
#         return render(request, 'login.html')



