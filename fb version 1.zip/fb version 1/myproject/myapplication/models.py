from django.db import models
from django.contrib.auth.models import User
# Create your models here.

#for fb user input
class Fbuser(models.Model):
    # user_id = models.AutoField(primary_key = True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    accesstoken = models.CharField(max_length=250, blank=True)
    page = models.BigIntegerField(50)
    app = models.BigIntegerField(50)

    class Meta:
        db_table = 'Fbuser'

    def __str__(self):
        return str(self.page)

#for storing user_id,Page_idand  Post_id

class Post(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    pgid = models.BigIntegerField(50) #pgid = pageid
    ptid = models.BigIntegerField(50)  #ptid = postid

    class Meta:
        db_table = 'Post'

    def __str__(self):
        return str(self.user)




